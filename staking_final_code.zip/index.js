const loadPoolsList = async () => {
    if (!window.publicContractWeb3) {
        setTimeout(loadPoolsList, 300);
        return;
    }

    console.log('Loading pools list...');

    const poolsList = document.querySelector("#pools-list");

    poolsList.innerHTML = `<tr class=\"del\" onclick=\"window.location='pool?pid=0'\">
                    <td>-</td>
                    <td>-%</td>
                    <td>- days</td>
                    <td id=\"balance-display-0\">0</td><td><button class=\"open\"> - </button></td>
            </tr>`;

    var i = 0, terminate = false, html = ``, pools = [];

    while (terminate === false) {
        await publicContractWeb3.methods.poolInfo(i.toString()).call().then(poolInfo => {
            pools.push(poolInfo);

            html += `<tr class="del" onclick="window.location='pool?pid=${i}'">
                    <td>${poolInfo.poolName}</td>
                    <td>${poolInfo.APY}%</td>
                    <td>${parseInt(poolInfo.duration) !== 0 ? parseInt(poolInfo.duration / 86400) + ` days` : `N/A`}</td>
                    <td id="balance-display-${i}">-</td>`;

            var statusPill;
            if (poolInfo.startTime > Date.now() / 1000) {
                statusPill = `<td><button class="closed"> Upcoming </button></td>`;
            }

            if (!statusPill && poolInfo.endTime < Date.now() / 1000) {
                statusPill = `<td><button class="closed"> Closed </button></td>`;
            }

            if (!statusPill && poolInfo.paused) {
                statusPill = `<td><button class="closed"> Paused </button></td>`;
            }

            if (!statusPill && poolInfo.balance / poolInfo.capacity * 100 > 98) {
                statusPill = `<td><button class="completed"> Completed </button></td>`;
            }

            if (!statusPill) {
                statusPill = `<td><button class="open"> Open </button></td>`;
            }

            html += statusPill + `
            </tr>`;
        }).catch(e => {
            terminate = true;
            console.log(`Terminated: ${e}`);
        });
        i++;
    }

    poolsList.innerHTML = html;

    console.log('from ', 0, 'to ', i - 1);
    updateBalances(0, i - 1, pools);
}

loadPoolsList();

const updateBalances = async (from, to, pools) => {
    if (!window.account) {
        setTimeout(() => updateBalances(from, to, pools), 700);
        return;
    }

    console.log(pools);

    for (let i = from; i <= to; i++) {
        const balDisp = document.querySelector(`#balance-display-${i}`);
        if (balDisp) {
            try {
                var totalAmountInvolved = await publicContractWeb3.methods.totalAmountInvolved(i.toString(), account).call();
                totalAmountInvolved = totalAmountInvolved / 10 ** pools[i].tokenInfo.decimals;
                balDisp.innerHTML = parseFloat(!isNaN(totalAmountInvolved) ? totalAmountInvolved.toFixed(6) : '0') +
                    " " + pools[i].tokenInfo.symbol;
            } catch (e) {
                console.log(`Error fetching pool ${i} balance: ${e}`);
                balDisp.innerHTML = `0`;
            }
        } else {
            console.log(`No balDisp for pid: ${i}`);
        }
    }
}