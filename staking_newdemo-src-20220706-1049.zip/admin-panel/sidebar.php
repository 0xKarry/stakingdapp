 <!-- Sidebar - Brand -->
 <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
     <div class="sidebar-brand-icon rotate-n-15">
         <i class="fas fa-laugh-wink"></i>
     </div>
     <div class="sidebar-brand-text mx-3"> Admin <sup></sup></div>
 </a>

 <!-- Divider -->
 <hr class="sidebar-divider my-0">

 <!-- Nav Item - Tables -->
 <!--<li class="nav-item active">-->
 <!--    <a class="nav-link" href="tables.php">-->
 <!--        <i class="fas fa-fw fa-table"></i>-->
 <!--        <span>User List</span></a>-->
 <!--</li>-->

 <li class="nav-item active">
     <a class="nav-link" href="admin_list.php">
         <i class="fas fa-fw fa-table"></i>
         <span>Admin List</span></a>
 </li>

 <!--<li class="nav-item active">-->
 <!--    <a class="nav-link" href="nft_list.php">-->
 <!--        <i class="fas fa-fw fa-table"></i>-->
 <!--        <span>NFT List</span></a>-->
 <!--</li>-->

 <!--<li class="nav-item active">-->
 <!--    <a class="nav-link" href="nft_contract.php">-->
 <!--        <i class="fas fa-fw fa-table"></i>-->
 <!--        <span>Contract Manage</span></a>-->
 <!--</li>-->

 <li class="nav-item active">
     <a class="nav-link" href="manage-pools">
         <i class="fas fa-fw fa-table"></i>
         <span>Manage Pools</span></a>
 </li>

 <!--<li class="nav-item active">-->
 <!--    <a class="nav-link" href="createNFT.php">-->
 <!--        <i class="fas fa-fw fa-table"></i>-->
 <!--        <span>Create NFT</span></a>-->
 <!--</li>-->