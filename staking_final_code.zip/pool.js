// Inputs
const stakeInput = document.querySelector("#stake-input");

const tokenBalanceDisp = document.querySelector('#token-balance');
const stakedAmountDisp = document.querySelector('#staked-amount');
const headingStakedAmount = document.querySelector('#heading-staked-amount');

// Large containers
const poolContainer = document.querySelector("#pool-container");
const stakesList = document.querySelector('#stakes-list');
const stakesErrorContainer = document.querySelector('#stakes-error-container');
const stakesListContainer = document.querySelector('#stakes-list-container');
const headingContainer = document.querySelector('#heading-container');
const poolInfoContainer = document.querySelector("#pool-info-container");
const rightSectionContainer = document.querySelector("#right-section-container");
const breadcrumbContainer = document.querySelector('#breadcrumb-container');

// buttons
const maxBtn = document.querySelector('#max');
const stakeBtn = document.querySelector('#stake-button');

maxBtn.addEventListener('click', async () => {
    if (!window.account) {
        stakeInput.value = '0';
        return;
    }

    const params = new URLSearchParams(window.location.search);
    var pid = params.get('pid');

    try {
        var poolInfo = await publicContractWeb3.methods.poolInfo(pid).call();
        const isWhitelisted = await publicContractWeb3.methods.isWhitelisted(pid, account).call();

        if (!isWhitelisted) {
            const tContract = new publicWeb3.eth.Contract(tokenContract.abi, poolInfo.tokenInfo.token);
            const balance = await tContract.methods.balanceOf(account).call();

            if (poolInfo.limitPerUser < balance) {
                stakeInput.value = parseFloat((poolInfo.limitPerUser / 10 ** poolInfo.tokenInfo.decimals).toFixed(6));
            } else {
                stakeInput.value = parseFloat((balance / 10 ** poolInfo.tokenInfo.decimals).toFixed(6));
            }
        } else {
            stakeInput.value = parseFloat((poolInfo.limitPerUser / 10 ** poolInfo.tokenInfo.decimals).toFixed(6));
        }
    } catch (e) {
        console.log(`maxBtn: ${e}`);
    }
});


const loadStakesList = async (poolInfo) => {
    if (!window.account) {
        stakesListContainer.style.display = "none";
        stakesErrorContainer.innerHTML = `
        <div class="container">
            <div class="row">
                <div class="col">
                    Please connect to view your stakes!
                </div>
            </div>
        </div>`;
        setTimeout(() => loadStakesList(poolInfo), 680);
        return;
    } else {
        stakesErrorContainer.innerHTML = ``;
        stakesListContainer.style.display = "block";
    }

    const params = new URLSearchParams(window.location.search);
    var pid = params.get('pid');

    if (pid === null || isNaN(pid)) {
        stakesListContainer.style.display = "none";
        return;
    }


    const isWhitelisted = await publicContractWeb3.methods.isWhitelisted(pid, account).call();

    console.log('isWhitelisted', isWhitelisted);

    if (poolInfo.poolType === "1" && isWhitelisted) {
        try {
            stakeBtn.removeEventListener('click', stake);
        } catch { }
        stakeBtn.innerHTML = `<input type="submit" value="Borrow" />`;
        stakeBtn.addEventListener('click', borrow);
    } else {
        try {
            stakeBtn.removeEventListener('click', borrow);
        } catch { }
        stakeBtn.innerHTML = `<input type="submit" value="Stake" />`;
        stakeBtn.addEventListener('click', stake);
    }

    breadcrumbContainer.innerHTML = `<div class="sub-inner mb-15">
                <a class="breadcrumbs-link" href="/staking_newdemo">Home</a>
                <span class="sub-title" id="breadcrumb-pathname">${poolInfo.poolType === "1" && isWhitelisted ? 'Borrow' : 'Staking'}</span>
                <img class="heading-left-image" src="assets/img/steps.png" alt="Steps-Image">
            </div>
            <h2 class="title mb-0" id="breadcrumb-heading">${poolInfo.poolType === "1" && isWhitelisted ? 'Borrow' : 'Staking'}</h2>`;

    publicContractWeb3.methods.totalAmountInvolved(pid, account)
        .call().then(totalAmountInvolved => {
            totalAmountInvolved = totalAmountInvolved / 10 ** poolInfo.tokenInfo.decimals;
            // headingStakedAmount.innerHTML = `${totalAmountInvolved} ${poolInfo.tokenInfo.symbol}`;

            totalAmountInvolved = parseFloat(parseFloat(totalAmountInvolved).toFixed(6));
            headingContainer.innerHTML = `
            <h4 class="mb-15" id="heading">${poolInfo.poolName}</h4>
            <h3 class="mb-15" id="heading-staked-amount">${totalAmountInvolved} ${poolInfo.tokenInfo.symbol}</h3>`;


            stakedAmountDisp.innerHTML = `${poolInfo.poolType === "1" && isWhitelisted ? 'Borrowed' : 'Staked'}: <strong>${totalAmountInvolved} ${poolInfo.tokenInfo.symbol}</strong>`;
        });

    var length = await publicContractWeb3.methods.totalStakesOfUser(pid, account).call();

    if (parseInt(length) === 0) {
        stakesListContainer.style.display = "none";
        stakesErrorContainer.innerHTML = `
        <div class="container">
            <div class="row">
                <div class="col">
                ${poolInfo.poolType === "1" && isWhitelisted
                ? `You haven't borrowed anything from this pool.`
                : `You don't have any stakes in this pool yet! Start staking!`}
                </div>
            </div>
        </div>`;
        return;
    }

    var stakes = await publicContractWeb3.methods.getUserStakes(pid, account, 0, length - 1).call();


    console.log('stakes: ', stakes);

    stakesList.innerHTML = `Loading...`;

    var html = `<thead>
        <tr>
            <th scope="col">S. No.</th>

            <th scope="col">Start</th>

            ${poolInfo.poolType === "0" ? `<th scope="col">Ends</th>` : ``}

            <th scope="col">${poolInfo.poolType === "1" && isWhitelisted ? `Borrowed` : `Locked`}</th>

            <th scope="col">${poolInfo.poolType === "1" && isWhitelisted ? `Interest` : `Accumulated Interest`}</th>

            ${poolInfo.poolType !== "1" && poolInfo.quarterlyPayout !== false ?
            `<th scope="col">Claimed Rewards</th>` : ``}

            ${poolInfo.poolType !== "1" && poolInfo.quarterlyPayout !== false ?
            `<th scope="col">QUARTERLY PAYOUT</th>` : ``}
            <th scope="col"></th>

        </tr>
    </thead>`;

    stakes.map((stake, i) => {
        var timeDiff = parseInt(Date.now() / 1000 - stake.time);

        html += `<tbody id="stakes-list">
            <tr>
                <th scope="row">${i + 1}</th>
                <td>${new Date(stake.time * 1e3).toLocaleDateString()}
                </td>

                ${poolInfo.poolType === "0" ? `<td>${new Date(stake.time * 1e3 + poolInfo.duration * 1e3).toLocaleDateString()}
                </td>` : ``}

                <td>${parseFloat((stake.amount / 10 ** poolInfo.tokenInfo.decimals).toFixed(6))} ${poolInfo.tokenInfo.symbol}
                </td>

                <td>${poolInfo.poolType === "0" ?
                parseFloat(((timeDiff > poolInfo.duration ? poolInfo.duration : timeDiff) * ((stake.amount * poolInfo.APY) /
                    (10 ** poolInfo.tokenInfo.decimals * 86400 * 100 * 365))).toFixed(6))
                : parseFloat((timeDiff * ((stake.amount * poolInfo.APY * poolInfo.utilisation) /
                    (10 ** poolInfo.tokenInfo.decimals * 100 * 86400 * 100 * 365))).toFixed(6))} ${poolInfo.tokenInfo.symbol}

            ${poolInfo.poolType !== "1" && poolInfo.quarterlyPayout !== false ?
                `<td>${parseFloat((stake.paidOut / 10 ** poolInfo.tokenInfo.decimals).toFixed(6))}</td> ` : ``}

            ${poolInfo.poolType !== "1" && poolInfo.quarterlyPayout !== false ?
                `<td><button class="claim" onClick="claimQuarterlyPayout(${pid}, ${i})"> Claim </button></td>` : ``}
            
            <td>
            ${!(poolInfo.poolType === "1" && isWhitelisted) ? `<button class="claim" onClick="claim(${pid}, ${i})"> Withdraw </button>`
                : `<button class="claim" onClick="repay(${pid}, ${i})"> Repay </button>`}
            </td>
            </tr>
        </tbody>`;
    });

    stakesList.innerHTML = html;
}


const updateMyTokenBalance = async (poolInfo) => {
    if (!window.publicWeb3 || !window.account) {
        setTimeout(() => updateMyTokenBalance(poolInfo), 500);
        return;
    }

    console.log('calculating balance of ', poolInfo.tokenInfo.token, ' with decimals ', poolInfo.tokenInfo.decimals)
    const tContract = new publicWeb3.eth.Contract(tokenContract.abi, poolInfo.tokenInfo.token);

    var balance = await tContract.methods.balanceOf(account).call();

    const tokenBalance = parseFloat((balance / 10 ** poolInfo.tokenInfo.decimals).toFixed(6));
    console.log(tokenBalance);

    tokenBalanceDisp.innerHTML = `
        ${!isNaN(tokenBalance) ? tokenBalance : "0"} 
        <span class="buse">
            ${poolInfo.tokenInfo.symbol}
        </span>`;
}

const borrow = async () => {
    if (!window.contractWeb3 || !window.account || !window.web3) {
        Swal.fire({
            title: 'Please connect!',
            text: 'Please connect with a wallet!',
            icon: 'warning'
        }).then(({ isConfirmed }) => isConfirmed && showModal());
        return;
    }

    const params = new URLSearchParams(window.location.search);
    var pid = params.get('pid');

    pid = pid.toString();

    amount = stakeInput.value;

    if (amount === "" || amount === '0') {
        Swal.fire({
            title: 'Invalid amount!',
            text: 'Please enter a valid amount!',
            icon: 'warning'
        });
        return;
    }

    document.querySelector('#loadingdiv').className = 'd-block';
    try {
        const poolInfo = await contractWeb3.methods.poolInfo(pid).call();

        const valueToSend = BigInt(amount * 10 ** poolInfo.tokenInfo.decimals);

        const gasLimit = await contractWeb3.methods.borrow(pid, valueToSend)
            .estimateGas({ from: account });

        await contractWeb3.methods.borrow(pid, valueToSend)
            .send({ from: account, gasLimit: gasLimit });

        Swal.fire({
            icon: 'success',
            title: 'Congratulations 🎉',
            text: 'You have successfully borrowed the amount!'
        });

        loadPoolInfo();
    } catch (e) {
        console.log(e);
        handleProviderError(e);
    }

    document.querySelector('#loadingdiv').className = 'd-none';
}

const repay = async (pid, index) => {
    if (!window.contractWeb3 || !window.account) {
        Swal.fire({
            title: 'Please connect!',
            text: 'Please connect with a wallet!',
            icon: 'warning'
        }).catch(({ isConfirmed }) => isConfirmed && showModal());
        return;
    }

    pid = pid.toString();
    index = index.toString();

    document.querySelector('#loadingdiv').className = 'd-block';

    try {
        const poolInfo = await contractWeb3.methods.poolInfo(pid).call();

        const tContract = new web3.eth.Contract(tokenContract.abi, poolInfo.tokenInfo.token);

        if (true) {
            let gasLimit0 = await tContract.methods.approve(contract.address, BigInt(1e30)).estimateGas({ from: account });
            await tContract.methods.approve(contract.address, BigInt(1e30)).send({ from: account, gasLimit: gasLimit0 });
        }

        let gasLimit = await contractWeb3.methods.repay(pid, index).estimateGas({ from: account });
        await contractWeb3.methods.repay(pid, index).send({ from: account, gasLimit: gasLimit });

        Swal.fire({
            icon: 'success',
            title: 'Congratulations 🎉',
            text: 'You have successfully repaid the amount!'
        });

        loadPoolInfo();
    } catch (e) {
        console.log(e);
        handleProviderError(e);
    }
    document.querySelector('#loadingdiv').className = 'd-none';
}

const claimQuarterlyPayout = async (pid, index) => {
    if (!window.contractWeb3 || !window.account || !window.web3) {
        Swal.fire({
            title: 'Please connect!',
            text: 'Please connect with a wallet!',
            icon: 'warning'
        }).then(({ isConfirmed }) => isConfirmed && showModal());
        return;
    }

    pid = pid.toString();
    index = index.toString();

    document.querySelector('#loadingdiv').className = 'd-block';

    try {
        const gasLimit = await contractWeb3.methods.claimQuarterlyPayout(pid, index)
            .estimateGas({ from: account });

        await contractWeb3.methods.claimQuarterlyPayout(pid, index)
            .send({ from: account, gasLimit: gasLimit });

        Swal.fire({
            icon: 'success',
            title: 'Congratulations 🎉',
            text: 'Your rewards were successfully claimed!'
        });

        loadPoolInfo();
    } catch (e) {
        console.log(e);
        handleProviderError(e);
    }

    document.querySelector('#loadingdiv').className = 'd-none';
}

const stake = async () => {
    console.log('stake called')
    if (!window.contractWeb3 || !window.account || !window.web3) {
        Swal.fire({
            title: 'Please connect!',
            text: 'Please connect with a wallet!',
            icon: 'warning'
        }).then(({ isConfirmed }) => isConfirmed && showModal());
        return;
    }

    const params = new URLSearchParams(window.location.search);
    var pid = params.get('pid');

    pid = pid.toString();

    amount = stakeInput.value;

    if (amount === "" || amount === '0') {
        Swal.fire({
            title: 'Invalid amount!',
            text: 'Please enter a valid amount!',
            icon: 'warning'
        });
        return;
    }

    document.querySelector('#loadingdiv').className = 'd-block';
    try {
        const poolInfo = await contractWeb3.methods.poolInfo(pid).call();

        const tContract = new web3.eth.Contract(tokenContract.abi, poolInfo.tokenInfo.token);

        const valueToSend = BigInt(amount * 10 ** poolInfo.tokenInfo.decimals);

        var allowance = await tContract.methods.allowance(account, contract.address).call();

        if (allowance < valueToSend) {
            const gasLimit0 = await tContract.methods.approve(contract.address, BigInt(1e30)).estimateGas({ from: account });
            await tContract.methods.approve(contract.address, BigInt(1e30)).send({ from: account, gasLimit: gasLimit0 });
        }

        const gasLimit = await contractWeb3.methods.deposit(pid.toString(), valueToSend)
            .estimateGas({ from: account });

        await contractWeb3.methods.deposit(pid.toString(), valueToSend)
            .send({ from: account, gasLimit: gasLimit });

        Swal.fire({
            icon: 'success',
            title: 'Congratulations 🎉',
            text: 'Your amount was successfully staked!'
        });

        loadPoolInfo();
    } catch (e) {
        console.log(e);
        handleProviderError(e);
    }

    document.querySelector('#loadingdiv').className = 'd-none';
}

const claim = async (pid, index) => {
    if (!window.contractWeb3 || !window.account) {
        Swal.fire({
            title: 'Please connect!',
            text: 'Please connect with a wallet!',
            icon: 'warning'
        }).catch(({ isConfirmed }) => isConfirmed && showModal());
        return;
    }

    pid = pid.toString();
    index = index.toString();
    document.querySelector('#loadingdiv').className = 'd-block';
    try {
        let gasLimit = await contractWeb3.methods.withdraw(pid, index).estimateGas({ from: account });
        await contractWeb3.methods.withdraw(pid, index).send({ from: account, gasLimit: gasLimit });
        Swal.fire({
            icon: 'success',
            title: 'Congratulations 🎉',
            text: 'Your amount was successfully withdrawn!'
        });

        loadPoolInfo();
    } catch (e) {
        console.log(e);
        handleProviderError(e);
    }
    document.querySelector('#loadingdiv').className = 'd-none';
}


const loadPoolInfo = async () => {
    if (!window.publicContractWeb3) {
        setTimeout(loadPoolInfo, 150);
        return;
    }

    const params = new URLSearchParams(window.location.search);
    var pid = params.get('pid');

    if (pid === null || isNaN(pid)) {
        poolContainer.innerHTML = `
        <div class="container">
            <div class="row">
                <div class="col">
                    Page not found!
                </div>
            </div>
        </div>`;
        stakesListContainer.style.display = "none";
        return;
    }

    pid = pid.toString();

    const poolType = await publicContractWeb3.methods.poolType(pid).call();

    publicContractWeb3.methods.poolInfo(pid).call().then(async (poolInfo) => {
        poolInfo = { poolType: poolType, ...poolInfo };
        console.log(poolInfo);

        try {
            stakeBtn.removeEventListener('click', borrow);
        } catch { }
        stakeBtn.innerHTML = `<input type="submit" value="Stake" />`;
        stakeBtn.addEventListener('click', stake);

        var poolLoanedBalance, utilisation;
        if (poolInfo.poolType === "1") {

            poolLoanedBalance = await publicContractWeb3.methods.poolLoanedBalance(pid).call();
            console.log('poolLoanedBalance', poolLoanedBalance);

            if (parseInt(poolInfo.balance) === 0)
                utilisation = 0;
            else
                utilisation = poolLoanedBalance / poolInfo.balance * 100;

            console.log("Pool Utilisation: ", parseFloat(parseFloat(utilisation).toFixed(2)));
            poolInfo = { ...poolInfo, poolLoanedBalance: poolLoanedBalance, utilisation: utilisation };
        }

        const {
            poolName,
            tokenInfo,
            uniqueUsers,
            limitPerUser,
            capacity,
            quarterlyPayout,
            startTime,
            endTime,
            balance,
            duration,
            APY
        } = poolInfo;

        var statusPill;
        if (poolInfo.startTime > Date.now() / 1000) {
            statusPill = `<button class="closed"> Upcoming </button>`;
        }

        if (!statusPill && poolInfo.endTime < Date.now() / 1000) {
            statusPill = `<button class="closed"> Closed </button>`;
        }

        if (!statusPill && poolInfo.paused) {
            statusPill = `<button class="closed"> Paused </button>`;
        }

        if (!statusPill && poolInfo.balance / poolInfo.capacity * 100 > 98) {
            statusPill = `<button class="completed"> Completed </button>`;
        }

        if (!statusPill) {
            statusPill = `<button class="open"> Open </button>`;
        }

        var balToDisplay = parseInt(balance / 10 ** tokenInfo.decimals);
        headingContainer.innerHTML = `
            <h4 class="mb-15" id="heading">${poolName}</h4>
            <h3 class="mb-15" id="heading-staked-amount">-</h3>`;

        poolInfoContainer.innerHTML = `
            <li>
                Status: ${statusPill}
            </li>
            <li>
                Pool Type: <strong >${poolType === "0" ? "Staking" : "Loan"}</strong>
            </li>
            ${poolType === "0" ? `<li>
                Start Date: <strong>${new Date(startTime * 1e3).toLocaleDateString()}</strong>
            </li>` : ``} 

            ${poolType === "0" ? `<li>
                End Date: <strong>${new Date(endTime * 1e3).toLocaleDateString()}</strong>
            </li>` : ``}

            ${poolType === "0" ? `<li>
                Lockup Period:
                <strong>${parseInt(duration / 86400)} Days</strong>
            </li>` : ``}

            ${poolType === "0" ? `<li>
                Eligible for quarterly payouts: <strong>${quarterlyPayout !== false ? "Yes" : "No"}</strong>
            </li>` : ``}

            <li>Pool Capacity: ${parseInt(capacity / 10 ** tokenInfo.decimals)} ${tokenInfo.symbol}</li>
            
            <li id="limitPerUser">Maximum Deposit: ${limitPerUser / 10 ** tokenInfo.decimals} ${tokenInfo.symbol}
        </li>`;

        rightSectionContainer.innerHTML = `<div class="project-item project-value-inner d-flex justify-content-between align-items-center mb-30">
            <div class="project-value">
                <h3 class="mb-15">${balToDisplay} ${tokenInfo.symbol}</h3>
                <span>Total Tokens Locked</span>
            </div>
            <div class="project-value-image">
                <img class="heading-right-image" src="assets/img/rank.png" alt="rank" />
            </div>
            </div>
            <div class="project-item project-value-inner d-flex justify-content-between align-items-center mb-30">
                <div class="project-value">
                    <h3 class="mb-15">${poolInfo.poolType === '0' ? APY :
                `${utilisation > 100 ? APY : parseFloat((APY * utilisation / 100).toFixed(2))}`}%</h3>
                    <span>${poolInfo.poolType === '0' ? `APY` : `Current APY`}</span>
                </div>
                <div class="project-value-image">
                    <img class="heading-right-image" src="assets/img/rank.png" alt="rank" />
                </div>
            </div>
            <div class="project-item project-value-inner d-flex justify-content-between align-items-center">
                <div class="project-value">
                    <h3 class="mb-15">${uniqueUsers}</h3>
                    <span>Pool Users</span>
                </div>
                <div class="project-value-image">
                    <img class="heading-right-image" src="assets/img/rank.png" alt="rank" />
                </div>
            </div>`;


        loadStakesList(poolInfo);
        updateMyTokenBalance(poolInfo);
    }).catch(e => {
        poolContainer.innerHTML = `
        <div class="container">
            <div class="row">
                <div class="col">
                    There were some issues loading that page!
                </div>
            </div>
        </div>`;
        stakesListContainer.style.display = "none";
        console.log(`Issues loading pool info with pid ${pid}: ${e}`);
    })
}

loadPoolInfo();