const totalPoolsDisplay = document.querySelector('#total-pools-display');


const totalPools = () => {
    if(!window.publicContractWeb3) {
        setTimeout(totalPools, 450);
        return;
    }

    try {
        publicContractWeb3.methods.totalPools().call().then(data => {
            totalPoolsDisplay.innerHTML = data;
        })
    } catch (e) {
        console.log('issues loading totalPools: ', e);
    }
}

totalPools();