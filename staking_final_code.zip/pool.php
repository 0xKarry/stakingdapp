<? include('header.php') ?>
<div class="banner_sec">
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <div class="breadcrumbs-area sec-heading" id="breadcrumb-container">
                    <div class="sub-inner mb-15">
                        <a class="breadcrumbs-link" href="/staking_newdemo">Home</a>
                        <span class="sub-title" id="breadcrumb-pathname">Staking</span>
                        <img class="heading-left-image" src="assets/img/steps.png" alt="Steps-Image">
                    </div>
                    <h2 class="title mb-0" id="breadcrumb-heading">Staking</h2>
                </div>
            </div>
            <div class="col-lg-7 breadcrumbs-form md-mt-30">
            </div>
        </div>
    </div>
</div>

<div class="participat-information project-details-conent gamfi-about-secion pt-5 pb-5" id="pool-container">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="project-item h-100 mt-3">
                    <div class="project-info border-bottom-2" id="heading-container">
                        <h4 class="mb-15" id="heading">-</h4>
                        <h3 class="mb-15" id="heading-staked-amount">-</h3>
                    </div>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <div class="project-media mb-40">
                                <ul class="project-listing" id="pool-info-container">
                                    <li>
                                        PoolType: <strong id="poolType">-</strong>
                                    </li>
                                    <li>
                                        Status: <strong id="status">-</strong>
                                    </li>
                                    <li>
                                        Start Date: <strong id="start-date">-</strong>
                                    </li>
                                    <li>
                                        End Date: <strong id="end-date">-</strong>
                                    </li>
                                    <li>
                                        Lockup period: <strong id="lock-period">-</strong>
                                    </li>
                                    <li>
                                        Eligible for quarterly payouts: <strong id="quarterlyPayout">-</strong>
                                    </li>
                                    <li id="limitPerUser">
                                        -
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="project-form-list">
                        <h5 class="mb-18">
                            Balance: <strong id="token-balance">-</strong>
                        </h5>
                        <div class="balance-form-area mb-3">
                            <input type="text" id="stake-input" placeholder="0" />
                            <span class="max" id="max" style="cursor: pointer;">MAX</span>
                            <div class="white-shape-small approve" id="stake-button">
                                <input type="submit" value="Loading..." />
                            </div>
                        </div>
                        <h5 class="mb-18" id="staked-amount">
                            <!-- Loading... -->
                            <!-- <strong>-</strong> -->
                        </h5>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 pl-25 md-pl-15 mt-3" id="right-section-container">
                <div class="project-item project-value-inner d-flex justify-content-between align-items-center mb-30">
                    <div class="project-value">
                        <h3 class="mb-15" id="pool-balance">-</h3>
                        <span>Total -</span>
                    </div>
                    <div class="project-value-image">
                        <img class="heading-right-image" src="assets/img/rank.png" alt="rank" />
                    </div>
                </div>
                <div class="project-item project-value-inner d-flex justify-content-between align-items-center mb-30">
                    <div class="project-value">
                        <h3 class="mb-15" id="APY">-</h3>
                        <span>Apy</span>
                    </div>
                    <div class="project-value-image">
                        <img class="heading-right-image" src="assets/img/rank.png" alt="rank" />
                    </div>
                </div>
                <div class="project-item project-value-inner d-flex justify-content-between align-items-center">
                    <div class="project-value">
                        <h3 class="mb-15" id="number-of-stakers">-</h3>
                        <span>Pool Users</span>
                    </div>
                    <div class="project-value-image">
                        <img class="heading-right-image" src="assets/img/rank.png" alt="rank" />
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="leaderboard pt-5 pb-5" id="stakes-list-container">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <table class="table" id="stakes-list">
                    <!-- <thead>
                        <tr>
                            <th scope="col">NO.</th>
                            <th scope="col">START</th>
                            <th scope="col">ENDS</th>
                            <th scope="col">LOCKED</th>
                            <th scope="col">REWARDS</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody> -->
                </table>
            </div>
        </div>
    </div>
</div>

<div class="leaderboard pt-5 pb-5" id="stakes-error-container"></div>

<script src="pool.js?v=<?php echo filemtime('pool.js'); ?>"></script>
<? include('footer.php') ?>