poolListTable = document.querySelector('#pool-list-table');

var addPoolInputValues = {
    poolType: "",
    poolName: "",
    tokenInfo: {
        token: "",
        collateralToken: "",
        name: "0",
        symbol: "0",
        decimals: "",
    },
    APY: "",
    durationVal: "",
    durationMultiplier: "86400",
    duration: "",
    startTime: "",
    endTime: "",
    limitPerUser: "",
    balance: "0",
    capacity: "",
    paused: false,
    quarterlyPayout: false,
    uniqueUsers: "0",
}

function contractCreate() {
    let web3 = new Web3(provider);

    let decimals = document.getElementById("decimals").value;

    if (!decimals || decimals === "") {
        Swal.fire({
            icon: 'info',
            title: 'Decimals unknown',
            text: 'Decimals are unknown. Please ensure that you\'re using the right token contract address!'
        });
        return;
    }

    let contractWeb3 = new web3.eth.Contract(abi, contract_address);

    contractWeb3.methods.mintToken(contract.address, decimals)
        .send({
            from: account
        }).on("transactionHash", function(hash) {
            console.log("hash,", hash);
        }).
    then(async res => {
        let token = await contractWeb3.methods._token().call();
        document.getElementById("collateralToken").value = token;
    }).catch(err => {
        console.log(err, "err");
    })
}

const handleAddPoolInputChange = e => {
    var { value, name } = e.target;

    switch (name) {
        case "poolType":
            document.querySelector("#apy-label").innerHTML = value === '0' ? `APY (%)` : `Max APY (%)`;
            document.querySelector("#quarterlyPayout-select").style.display = value === '0' ? `block` : `none`;

            if (value === '1') {
                document.querySelector("#durationVal").value = "0";
                document.querySelector("#durationMultiplier").value = "86400";
                document.querySelector("#lockup-period-form").style.display = "none";

                addPoolInputValues = {
                    ...addPoolInputValues,
                    durationVal: "0",
                    durationMultiplier: "86400",
                    duration: "0",
                }
            } else {
                document.querySelector("#durationVal").value = "";
                document.querySelector("#durationMultiplier").value = "86400";
                document.querySelector("#lockup-period-form").style.display = "block";

                addPoolInputValues = {
                    ...addPoolInputValues,
                    durationMultiplier: "86400",
                    durationVal: "",
                    duration: "",
                }
            }
            break;
        case "startTime":
        case "endTime":
            value = (new Date(value).getTime() / 1000).toString();
            break;
        case "durationVal":
            addPoolInputValues = {
                ...addPoolInputValues,
                duration: String(value * addPoolInputValues.durationMultiplier)
            }
            break;
        case "durationMultiplier":
            addPoolInputValues = {
                ...addPoolInputValues,
                duration: String(addPoolInputValues.durationVal * value)
            }
            break;
        case "quarterlyPayout":
        case "paused":
            value = value === "0" ? false : true;
            break;
        case "token":
        case "collateralToken":
        case "name":
        case "decimals":
        case "symbol":
            if(name === "token" && web3) {
                async function updateDecimals(value) {
                    if(value.length === 42) {
                        try {
                            var tContract = new web3.eth.Contract(tokenContract.abi, value);
                            let decimals = await tContract.methods.decimals().call();
                            addPoolInputValues.tokenInfo.decimals = decimals;
                            document.querySelector("#decimals").value = decimals;
                        } catch (e) {
                            console.error('updating decimals ', e);
                        }
                    }
                }
                updateDecimals(value);
                console.log('updating decimal')
            }
            console.log('name')

            addPoolInputValues = {
                ...addPoolInputValues,
                tokenInfo: {
                    ...addPoolInputValues.tokenInfo,
                    [name]: value,
                }
            };
            console.log(addPoolInputValues);
            return;
        default:
            break;
    }

    addPoolInputValues = {
        ...addPoolInputValues,
        [name]: value,
    }

    console.log(addPoolInputValues);
}

$("#submitBtn").on('click', async (e) => {
    e.preventDefault();
    var account = sessionStorage.getItem('account');
    if (!account || !contractWeb3 || !web3) {
        Swal.fire({
            icon: 'info',
            text: 'You need to connect with a wallet before you can perform this action!',
        }).then(({ isConfirmed }) => {
            isConfirmed && showModal();
        });
        return;
    }

    // Check all poolInfo entries have been filled
    for (const [key, value] of Object.entries(addPoolInputValues)) {
        if (value === "") {
            Swal.fire({ icon: 'info', text: 'Please fill out all required fields!' });
            return;
        }
    }

    // Check all tokenInfo entries have been filled
    for (const [key, value] of Object.entries(addPoolInputValues.tokenInfo)) {
        if (value === "") {
            Swal.fire({ icon: 'info', text: 'Please fill out all required fields!' });
            return;
        }
    }

    function expandToDecimals(amount, dec) {
        stringf = "";
        for (var i = 0; i < dec; i++) {
            stringf = stringf + "0";
        }
        return amount + stringf;
    }

    var poolInfo = {
        ...addPoolInputValues,
        limitPerUser: expandToDecimals(addPoolInputValues.limitPerUser, addPoolInputValues.tokenInfo.decimals),
        capacity: expandToDecimals(addPoolInputValues.capacity, addPoolInputValues.tokenInfo.decimals),
    }

    console.log("Sending tuple: ", poolInfo);

    document.getElementById("loadingdiv").className = "d-block";
    try {
        var gasLimit = await contractWeb3.methods.createPool(poolInfo, poolInfo.poolType).estimateGas({
            from: account
        });

        await contractWeb3.methods.createPool(poolInfo, poolInfo.poolType).send({
            gasLimit: gasLimit,
            from: account
        });

        Swal.fire({
            title: 'Success!',
            icon: 'success',
            text: 'The pool was successfully created!'
        });

        loadPoolsList();
    } catch (e) {
        handleProviderError(e);
        console.log(e);
    }
    document.getElementById("loadingdiv").className = "d-none";
});

const loadPoolsList = async () => {
    if (!window.publicContractWeb3) {
        setTimeout(loadPoolsList, 300);
        return;
    }

    try {
        console.log('loading total pools ');
        const totalPools = await publicContractWeb3.methods.totalPools().call();

        const pools = await publicContractWeb3.methods.getPoolInfo("0", totalPools - 1).call();

        var html = `<thead>
            <tr>
                <th scope="col">Pool Name</th>
                <th scope="col">Pool Type</th>
                <th Scope="col">Lockup Period</th>
                <th Scope="col">Status</th>
                <th Scope="col">Deposited/Capacity %</th>
                <th Scope="col">Quarterly Payouts</th>
                <th Scope="col">Pause</th>
                <th scope="col">Whitelist</th>
            </tr>
        </thead>
        <tbody>`;

        pools.map(async (poolInfo, idx) => {
            const poolType = await publicContractWeb3.methods.poolType(idx.toString()).call();

            var statusPill;
            if (poolInfo.startTime > Date.now() / 1000) {
                statusPill = `<button class="closed"> Upcoming </button>`;
            }

            if (!statusPill && poolInfo.endTime < Date.now() / 1000) {
                statusPill = `<button class="closed"> Closed </button>`;
            }

            if (!statusPill && poolInfo.paused) {
                statusPill = `<button class="closed"> Paused </button>`;
            }

            if (!statusPill && poolInfo.balance / poolInfo.capacity * 100 > 98) {
                statusPill = `<button class="completed"> Completed </button>`;
            }

            if (!statusPill) {
                statusPill = `<button class="open"> Open </button>`;
            }

            html += `<tr>
            <td scope="col">${poolInfo.poolName}</td>
            <td scope="col">${poolType === '0' ? 'Staking' : 'Loan'}</td>
            <td Scope="col">${parseInt(poolInfo.duration) !== 0 ? parseInt(poolInfo.duration / 86400) + ` days` : `N/A`} days</td>
            <td Scope="col">${statusPill}</td>
            <td Scope="col">${parseFloat((poolInfo.balance / poolInfo.capacity * 100).toFixed(2))}%</td>
            <td Scope="col">${poolType === '0' ? `${poolInfo.quarterlyPayout ? 'Enabled' : 'Disabled'}` : `N/A`}</td>
            <td Scope="col">
                <div class="input-group flex-nowrap">
                ${!poolInfo.paused ? `<button onClick="setPoolPaused(${idx}, true)" class="btn btn-danger" type="button">Pause</button>`
                    : `<button onClick="setPoolPaused(${idx}, false)" class="btn btn-primary" type="button">Resume</button>`}
                </div>
            </td>
            <td scope="col">
                ${poolType === "1" ? `<div class="input-group">
                    <input id="whitelist-input-${idx}" type="text" class="form-control" placeholder="Address" aria-label="Address input with add and remove button">
                    <button onClick="whitelist(${idx}, true)" class="btn btn-outline-primary" type="button">Add</button>
                    <button onClick="whitelist(${idx}, false)" class="btn btn-outline-secondary" type="button">Remove</button>
                </div>` : `N/A`}
            </td>
            </tr>`;

            if (idx === pools.length - 1) {
                html += `</tbody>`

                poolListTable.innerHTML = html;
            }
        });
    } catch (e) {
        console.log('error loading pools list: ', e);
    }
}

loadPoolsList();

const setPoolPaused = async (pid, newStatus) => {
    var account = sessionStorage.getItem('account');
    if (!account || !contractWeb3 || !web3) {
        Swal.fire({
            icon: 'info',
            text: 'You need to connect with a wallet before you can perform this action!',
        }).then(({ isConfirmed }) => {
            isConfirmed && showModal();
        });
        return;
    }

    pid = pid.toString();

    document.getElementById("loadingdiv").className = "d-block";
    try {
        let gasLimit = await contractWeb3.methods.setPoolPaused(pid, newStatus).estimateGas({ from: account });
        await contractWeb3.methods.setPoolPaused(pid, newStatus).send({ from: account, gasLimit: gasLimit });

        Swal.fire({
            icon: 'success',
            title: 'Success!',
            text: `The pool was successfully ${newStatus === true ? 'paused' : 'resumed'}!`,
        });

        loadPoolsList();
    } catch (e) {
        handleProviderError(e);
        console.log(e);
    }

    document.getElementById("loadingdiv").className = "d-none";
}


const whitelist = async (pid, newStatus) => {
    var account = sessionStorage.getItem('account');
    if (!account || !contractWeb3 || !web3) {
        Swal.fire({
            icon: 'info',
            text: 'You need to connect with a wallet before you can perform this action!',
        }).then(({ isConfirmed }) => {
            isConfirmed && showModal();
        });
        return;
    }

    var address = document.querySelector(`#whitelist-input-${pid}`).value;

    if (!address || address === '') {
        Swal.fire({
            icon: 'success',
            title: 'Success!',
            text: 'Please enter an address!',
        })
    }

    pid = pid.toString();

    document.getElementById("loadingdiv").className = "d-block";
    try {
        let gasLimit = await contractWeb3.methods.whitelist(pid, address, newStatus).estimateGas({ from: account });
        await contractWeb3.methods.whitelist(pid, address, newStatus).send({ from: account, gasLimit: gasLimit });

        Swal.fire({
            icon: 'success',
            title: 'Success!',
            text: `The address ${address} was successfully ${newStatus === true ? 'whitelisted' : 'removed from whitelist'}.`,
        });

        // loadPoolsList();
    } catch (e) {
        handleProviderError(e);
        console.log(e);
    }

    document.getElementById("loadingdiv").className = "d-none";
}