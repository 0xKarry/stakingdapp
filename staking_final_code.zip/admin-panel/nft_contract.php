<? session_start();
if (empty($_SESSION['email'])) {
    header('Location: ./login.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/web3/1.3.6/web3.min.js" integrity="sha512-jMEcX0Bev3VsCrACqEM3BFZvAMFXJSuTsMu0SttkAdMjquip6p3Oty5bbXrfg4T8n4g5BQYkGKxzLsrSqQgLUQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <? include("../api/config.php");
    if (isset($_POST['nft_up'])) {
        $id = $_POST['nft_up'];
        $pp = mysqli_query($link, "select Id from nft_user where user_priority=" . $_POST['nft' . $id]);
        foreach ($pp as $p) {
            mysqli_query($link, "UPDATE `nft_user` SET `user_priority`=0 WHERE `Id`=" . $p['Id']);
        }
        mysqli_query($link, "UPDATE `nft_user` SET `user_priority`=" . $_POST['nft' . $id] . " WHERE `Id`=" . $id);
        echo "<script>alert('User Data Update Successfully');</script>";
    }
    if (isset($_POST['nft_status_b'])) {
        mysqli_query($link, "UPDATE `nft_user` SET `block`=1 WHERE `Id`=" . $_POST['nft_status_b']);
        echo "<script>alert('User Blocked Successfully');</script>";
    }
    if (isset($_POST['nft_status_unb'])) {
        mysqli_query($link, "UPDATE `nft_user` SET `block`=0 WHERE `Id`=" . $_POST['nft_status_unb']);
        echo "<script>alert('User UnBlocked Successfully');</script>";
    }
    if (isset($_POST['nft_delete'])) {
        mysqli_query($link, "DELETE FROM `nft_user` WHERE `Id`=" . $_POST['nft_delete']);
        echo "<script>alert('User Deleted Successfully');</script>";
    }
    $ress = mysqli_query($link, "SELECT * FROM `nft_user` order by id desc");

    ?>
    <script>
        // CONNECT WALLET FUNCTION
        const connectWallet = async () => {
            try {
                if (window.ethereum) {

                    try {
                        wallet = "Metamask";
                        await window.ethereum.enable();
                        provider = await window.web3.currentProvider;
                        web3 = await new Web3(provider);
                        chainId = await web3.eth.net.getId();
                        let accounts = await web3.eth.getAccounts();
                        provider = await window.web3.currentProvider;
                        connectedAccount = accounts[0];
                        if (chainId == 4 || chainId == 1) {
                            document.getElementById("artistAddress").innerHTML = connectedAccount;
                            sessionStorage.removeItem("wallet");
                            sessionStorage.clear();
                            sessionStorage.setItem("wallet", wallet);
                            document.getElementById("connectWallet").classList.add("d-none");
                            document.getElementById("disconnect").classList.remove("d-none");
                            // await fetchAccountData(web3);						
                        } else {
                            Swal.fire({
                                title: 'Please connect on Ethereum mainnet',
                                showCloseButton: false,
                                showCancelButton: false,
                                focusConfirm: false,
                                allowOutsideClick: false,
                                showConfirmButton: false,
                            })
                        }

                    } catch (err) {
                        Swal.fire('error', err.message, "error");
                    }


                } else {
                    Swal.fire('error', 'Not a Ethereum browser', "error");
                }
            } catch (e) {
                return;
            }
        }

        window.addEventListener('load', async () => {

            let wallet = sessionStorage.getItem("wallet");
            if (wallet == "Metamask") {
                connectWallet();
            } else if (wallet == "walletconnect") {
                connectWalletConnect();
            } else if (wallet == "tron") {
                connectTron();
            } else {
                console.log(wallet);
            }

        });

        window.ethereum.on('accountsChanged', function(accounts) {
            let wallet = sessionStorage.getItem("wallet");
            if (wallet == "Metamask") {
                connectWallet();
            } else if (wallet == "walletconnect") {
                connectWalletConnect();
            } else if (wallet == "tron") {
                connectTron();
            }
            window.location.reload();
        })

        window.ethereum.on('networkChanged', function(accounts) {
            let wallet = sessionStorage.getItem("wallet");
            if (wallet == "Metamask") {
                connectWallet();
            } else if (wallet == "walletconnect") {
                connectWalletConnect();
            } else if (wallet == "tron") {
                connectTron();
            }
            window.location.reload();
        })


        const onDisconnect = async () => {
            provider = null;
            connectedAccount = null;
            sessionStorage.removeItem("wallet");
            sessionStorage.clear();
            document.getElementById("connectWallet").classList.remove("d-none");
            document.getElementById("disconnect").classList.add("d-none");

        }
        setTimeout(() => {
            connectWallet();
        }, 2000);
    </script>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
            <?php include("sidebar.php"); ?>
        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Main Content -->
            <div id="content">
                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $_SESSION['email'] ?></span>
                                <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                <!--<a class="dropdown-item" href="#">-->
                                <!--    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>-->
                                <!--    Profile-->
                                <!--</a>-->
                                <!--<a class="dropdown-item" href="#">-->
                                <!--    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>-->
                                <!--    Settings-->
                                <!--</a>-->
                                <!--<a class="dropdown-item" href="#">-->
                                <!--    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>-->
                                <!--    Activity Log-->
                                <!--</a>-->
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <section class="admin-page my-5">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="admin-top">
                                        <div class="row">
                                            <div class="col-md-7 pt-1">
                                                <h1 class="text-primary">
                                                    Manage Contract
                                                </h1>
                                            </div>
                                            <div class="col-md-7">
                                                <h6 class=" tron-address">
                                                    <span>Your wallet address:</span> <a href="#" class=""><span id="artistAddress"></span></a>
                                                </h6>
                                                <p>ℹ️ Make sure you're the owner of the contract with the above wallet address before attempting to change values.
                                                    Switch to the correct account in Metamask if this is not the case.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <h4 class=" mb-3 mt-2">NFT Creation Fees</h4>
                                </div>
                                <div class="col-md-12">
                                    <div class="nft-admin">
                                        <div class="row">
                                            <div class="col-md-8">
                                                <div class="form-group">
                                                    <input type="number" class="form-control" id="floorPriceToken" name="creating_fees_token" aria-describedby="emailHelp" placeholder="New NFT creation fees in Token">
                                                </div>
                                                <div class="form-group">
                                                    <input type="number" class="form-control" id="floorPrice" name="creating_fees" aria-describedby="emailHelp" placeholder="New NFT creation fees in Ether">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="submit-here">
                                        <button type="submit" onclick="setFloorPrice()" name="address" class="btn btn-primary form-control">Submit</button>
                                    </div>
                                </div>

                                <div class="col-md-12 mt-5">
                                    <h4 class=" mb-3">Enable/Disable Sale</h4>
                                </div>
                                <div class="col-md-12">
                                    <div class="nft-admin">
                                        <div class="row">
                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <button type="submit" class="btn btn-success" id="enableSale" onclick="setSaleStatus(true);">Enable Sale</button>
                                                </div>
                                            </div>

                                            <div class="col-md-10">
                                                <div class="form-group">
                                                    <button type="submit" class="btn btn-danger" id="disableSale" onclick="setSaleStatus(false);">Disable Sale</button>
                                                </div>
                                                <div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-12 mt-5">
                                            <h4 class=" mb-3">Set Base URI</h4>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="nft-admin">
                                                <div class="row">
                                                    <div class="col-md-8">
                                                        <div class="form-group">
                                                            <input type="text" class="form-control" id="newBaseURI" name="new_base_uri" aria-describedby="newBaseURI" placeholder="New base URI">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="submit-here">
                                                <button type="submit" onclick="setBaseURI()" name="address" class="btn btn-primary form-control">Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                    </section>
                    <hr>
                    <div id="loadingdiv" class="d-none" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 200;">
                        <div class="" style="display: flex; justify-content: center; align-items: center; flex-direction: column; width: 100%; height: 100vh; background: #1a080800;backdrop-filter: blur(10px);">
                            <h3>Transaction in process</h3>
                            <img src="https://scorep.co/uploads/loading-process.gif" class="rounded-pill" width="200" height="200" />
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.php">Logout</a>
                </div>
            </div>
        </div>
    </div>
    <div id="loadingdiv" class="d-none" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 200;">
        <div class="" style="display: flex; justify-content: center; align-items: center; flex-direction: column; width: 100%; height: 100vh; background: #1a080800; backdrop-filter: blur(10px);">
            <img src="./uploads/loading-process.gif" class="rounded-pill" width="105px" height="105px" />
            <h3 class="text-white">Transaction in progress. Please wait and do not refresh the page.</h3>
        </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>
    <!-- Page level plugins -->


    <!-- Page level custom scripts -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
    <script src="assets/slick/slick.min.js" type="text/javascript"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <script>
        $(document).ready(function() {
            $(".notification-drop .item").on('click', function() {
                $(this).find('ul').toggle();
            });
        });
    </script>

    <!-- <script src="../assets/js/contract.js"></script> -->

    <script src="../assets/js/contract.js?v=<?php echo filemtime('../assets/js/contract.js'); ?>"></script>
    <script src="../assets/js/script.js?v=<?php echo filemtime('../assets/js/script.js'); ?>"></script>

    <script>
        async function setFloorPrice() {
            let floorPriceToken = document.querySelector('#floorPriceToken').value,
                floorPriceEth = document.querySelector('#floorPrice').value;

            floorPriceToken = floorPriceToken.toString();
            floorPrice = floorPrice.toString();

            if (floorPriceToken === "" || floorPriceEth === "") {
                swal("warning", "Please fill out all fields", "warning")
                return;
            }

            if (provider == null && connectedAccount == null) {
                swal("warning", "Please connect wallet", "warning");
                return;
            }

            let myContract = await new web3.eth.Contract(contract.abi, contract.address);

            myContract.methods.setFloorPrice(web3.utils.toWei(floorPriceToken), web3.utils.toWei(floorPriceEth))
                .send({
                    from: connectedAccount
                }).then(async (receipt1) => {
                    document.getElementById("loadingdiv").className = "d-block";
                }).then(receipt => {
                    document.getElementById("loadingdiv").className = "d-none";
                    swal("Success!", "Floor prices updated successfully!", "success");
                }).catch(err => {
                    document.getElementById("loadingdiv").className = "d-none";
                    console.log(err);
                    swal("warning", "Something went wrong", "warning");
                });
        }

        async function setSaleStatus(newStatus) {
            let myContract = await new web3.eth.Contract(contract.abi, contract.address);
            myContract.methods.setSaleStatus(newStatus).send({
                from: connectedAccount
            }).then(async (receipt1) => {
                document.getElementById("loadingdiv").className = "d-block";
            }).then(receipt => {
                document.getElementById("loadingdiv").className = "d-none";
                swal("Success!", "Sale status updated successfully!", "success");
            }).catch(err => {
                document.getElementById("loadingdiv").className = "d-none";
                console.log(err);
                swal("warning", "Something went wrong", "warning");
            });
        }

        async function setBaseURI() {
            let myContract = await new web3.eth.Contract(contract.abi, contract.address);

            let newBaseURI = document.querySelector('#newBaseURI').value;

            if (newBaseURI === "") {
                swal('info', 'Please enter a new base URI', 'info');
                return;
            }

            // Add a trailing slash if not entered
            newBaseURI = newBaseURI.replace(/\/?$/, '/');

            myContract.methods.setBaseURI(newBaseURI).send({
                from: connectedAccount
            }).then(async (receipt1) => {
                document.getElementById("loadingdiv").className = "d-block";
            }).then(receipt => {
                document.getElementById("loadingdiv").className = "d-none";
                swal("Success!", "Set Base URI success!", "success");
            }).catch(err => {
                document.getElementById("loadingdiv").className = "d-none";
                console.log(err);
                swal("warning", "Something went wrong", "warning");
            });
        }

        async function lazyMint() {
            const lazyMintCountInput = document.querySelector('#lazy-mint-count');
            const purchaseCurrencySelect = document.querySelector('#purchse-currency-select');
            console.log(purchaseCurrencySelect.value);

            if (isNaN(lazyMintCountInput.value) || lazyMintCountInput.value == 0 || lazyMintCountInput.value === '' || purchaseCurrencySelect.value === "") {
                swal('info', 'Please fill all fields', 'info');
                return;
            }

            let myContract = await new web3.eth.Contract(contract.abi, contract.address);
            let totalSupply = await myContract.methods.totalSupply().call();
            let amount = 0;
            if (purchaseCurrencySelect.value == 1) {
                amount = web3.utils.fromWei(await myContract.methods.floorPriceToken().call(), 'ether');
            } else {
                amount = web3.utils.fromWei(await myContract.methods.floorPrice().call(), 'ether');
            }

            const formData = new FormData();
            formData.append("payment", purchaseCurrencySelect.value);
            formData.append('address', connectedAccount);
            formData.append('id', Number(totalSupply));
            formData.append('amount', amount);
            formData.append('lazy_mint', '1');

            var xhr = new XMLHttpRequest();
            xhr.withCredentials = true;

            xhr.addEventListener("readystatechange", async function() {
                if (this.readyState === 4) {
                    if (this.status == 200) {
                        swal("success", "Lazy Mint success", "success");
                    } else {
                        document.getElementById("loadingdiv").className = "d-none";
                        swal("warning", "Something went wrong", "warning");
                    }
                }
            });

            xhr.open("POST", "../api/savenft");

            xhr.send(formData);
        }
    </script>
</body>

</html>